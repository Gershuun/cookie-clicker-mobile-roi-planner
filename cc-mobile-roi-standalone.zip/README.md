# Cookie Clicker Mobile ROI Planner (Standalone)
Single-file version — no build tools, just open `index.html` or upload it to GitHub Pages.

## How to use
- Open `index.html` in your browser (double-click) **or** upload it to a repo and enable **GitHub Pages**.
- Tap **Import save** to paste your mobile export string (base64, often ends with `!END!`).

## Deploy free with GitHub Pages (drag & drop)
1. Create a new repo on GitHub (public).
2. Upload `index.html` (just this one file).
3. In repo **Settings → Pages**, set **Source: GitHub Actions** (or **Branch: main / root** if offered).
4. Your site will be live at `https://<you>.github.io/<repo>/`.

No Node. No Vite. No install.
